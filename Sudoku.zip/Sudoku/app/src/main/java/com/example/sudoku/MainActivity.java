package com.example.sudoku;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Chronometer;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    private GameView gV;

    // 1. 定义菜单项的标识
    final private int  OPEN = 111;
    public static ArrayList quizzes=new ArrayList<int [][]>();
    public static ArrayList solutions=new ArrayList<int [][]>();
    public static int[][][] partQuizzes= new int[30][9][9];
    public static int[][][] partSolutions= new int[30][9][9];

    public static String record="";

    public static Chronometer timer;
    int useTime=900;
    String useTimeString; //00:00  min,sec

    private Timer timerGlobal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        timer = (Chronometer) findViewById(R.id.timer);

        initData();
        //int[][] gdata= (int[][]) quizzes.get(0);
        gV = (GameView) findViewById(R.id.game);
        startTimer();

        timerGlobal=new Timer();
        timerGlobal.schedule(new TimerTask() {
            @Override
            public void run() {
                if(gV.success()){
                    stopTimer();
                    try {
                        Thread.sleep(500000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        },0,1000);//每隔一秒使用handler检测sudoku成功

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // 加载 XML 菜单目录
        getMenuInflater().inflate(R.menu.menu, menu);

        //menu.add(1,OPEN,0,"Open");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        // 菜单项被选中时触发
        int id = item.getItemId();
        String label = "";

        Log.d("OptionMenu",String.valueOf(id));

        switch (id){
            case R.id.create_new_game:
                label = "New Game";
                gV.repeat();
                break;
            case R.id.record:
                label = "Highest Record";
                showRecordDialog();
                break;
            case R.id.help:
                label = "Game Help";
                showHelpDialog();
                break;
            /*case OPEN:
                label = "Open";
                break;*/
        }

        Toast.makeText(getApplicationContext(),"What you clicked is :" + label,Toast.LENGTH_SHORT).show();

        return super.onOptionsItemSelected(item);
    }

    public void rePay(View v){
        startTimer();
        gV.repeat();
    }
    public void newPay(View v){
        startTimer();
        gV.play();
    }

    //Show the /game record
    public void showRecordDialog(){
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setTitle("Highest Record");
        builder.setMessage(record);
        builder.setPositiveButton("Ok, I know", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        AlertDialog dialog=builder.create();
        dialog.show();
    }

    //Show the /game Help dialog
    public void showHelpDialog(){
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setTitle("Game Helper");
        builder.setMessage(
                "Fill in the other spaces with numbers 1-9. " +
                "Each number from 1 to 9 appears only once in each row, column, and house, so it is also called 'nine palaces.'\n\n"+
                "Notice: If you complete the Sudoku in a shortest time, you can save your name.");

        builder.setPositiveButton("Ok, I know", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        AlertDialog dialog=builder.create();
        dialog.show();
    }



    public void initData(){

        try {
            InputStreamReader isr = new InputStreamReader(getResources().openRawResource(R.raw.record),"UTF-8");
            BufferedReader br = new BufferedReader(isr);
            String line;
            StringBuilder builder = new StringBuilder();
            while((line = br.readLine()) != null){
                builder.append(line);
            }
            br.close();
            isr.close();
            JSONObject recordJson = new JSONObject(builder.toString());//builder读取了JSON中的数据。
            //直接传入JSONObject来构造一个实例
            JSONArray arrayName = recordJson.getJSONArray("record");  //从JSONObject中取出数组对象
            JSONObject line0 = arrayName.getJSONObject(0);
            JSONObject line1 = arrayName.getJSONObject(1);
            record="Record\n"+"Name: "+line0.get("name")+"\n"+"Time: "+line0.get("time")+"s\n\n"+
                    "Name: "+line1.get("name")+"\n"+"Time: "+line1.get("time")+"s";
            }
            catch (Exception e) {
            e.printStackTrace();
        }

        //init quizzes and solutions, read sudoku.txt
        ArrayList newList=new ArrayList<String>();
        try {
            InputStream instream = getResources().openRawResource(R.raw.sudoku);
            if (instream != null)
            {
                InputStreamReader inputreader = new InputStreamReader(instream);
                BufferedReader buffreader = new BufferedReader(inputreader);
                String line;
                //分行读取
                while (( line = buffreader.readLine()) != null) {
                    newList.add(line+"\n");
                }
                instream.close();
            }
        }
        catch (java.io.FileNotFoundException e)
        {
            Log.d("TestFile", "The File doesn't not exist.");
        }
        catch (IOException e)
        {
            Log.d("TestFile", e.getMessage());
        }

        for(int i = 0; i < newList.size(); i++){
            String temp=newList.get(i).toString();
            int[][] questions= new int[9][9];
            int[][] answers= new int[9][9];
            int tempRow=0;
            int tempCol=0;

            for(int j=0; j<temp.length();j++)
            {
                if(j<81){
                    tempRow=j/9;
                    tempCol=j%9;
                    questions[tempRow][tempCol]=Character.getNumericValue(temp.charAt(j));
                }
                if(j==81);// ','
                if(j>81&&j<163){
                    tempRow=(j-82)/9;
                    tempCol=(j-82)%9;
                    answers[tempRow][tempCol]=Character.getNumericValue(temp.charAt(j));
                }
            }
            quizzes.add(questions);
            solutions.add(answers);

            if(i<30){
                for(int x=0; x<9; x++){
                    for(int y=0; y<9; y++){
                        partQuizzes[i][x][y]=questions[x][y];
                        partSolutions[i][x][y]=answers[x][y];
                    }
                }
            }
        }
    }

    public ArrayList getQuizzes(){
        return quizzes;
    }

    public ArrayList getSolutions(){
        return solutions;
    }

    public static int[][][] getPartQuizzes(){return partQuizzes;}
    public static int[][][] getPartSolutions(){return partSolutions;}

    //Timer start stop
    public void startTimer(){
        timer.setBase(SystemClock.elapsedRealtime());//Timer clears to 0
        //int hour = (int) ((SystemClock.elapsedRealtime() - timer.getBase()) / 1000 / 60);
        timer.setFormat("%s");
        timer.start();
    }

    public void stopTimer(){

        useTime=(int)(SystemClock.elapsedRealtime() - timer.getBase())/1000-1;
        useTimeString=getStringTime((int)(SystemClock.elapsedRealtime() - timer.getBase()));
        timer.stop();
        //timer.setBase(SystemClock.elapsedRealtime());//Timer clears to 0

        //Judge whether to record
        judgeRecord();
    }

    //get the time string 00:00
    private String getStringTime(int cnt) {
        //int hour = cnt/1000/60;
        int min = cnt/1000 % 60;
        int second = cnt % 60;
        return (min*60+second)+"";
        //return String.format(Locale.CHINA,"%02d:%02d",min,second);
    }

    private void judgeRecord(){
        try {
            InputStreamReader isr = new InputStreamReader(getResources().openRawResource(R.raw.record),"UTF-8");
            BufferedReader br = new BufferedReader(isr);
            String line;
            StringBuilder builder = new StringBuilder();
            while((line = br.readLine()) != null){
                builder.append(line);
            }
            br.close();
            isr.close();
            JSONObject recordJson = new JSONObject(builder.toString());//builder读取了JSON中的数据。
            //直接传入JSONObject来构造一个实例
            JSONArray array = recordJson.getJSONArray("record");  //从JSONObject中取出数组对象
            JSONObject line0 = array.getJSONObject(0);
            JSONObject line1 = array.getJSONObject(1);
            if(useTime<Integer.parseInt(line0.get("time").toString())){
                line0.put("time",useTime+"");
            }
            record="Record\n"+"Name: "+line0.get("name")+"\n"+"Time: "+line0.get("time")+"s\n\n"+
                    "Name: "+line1.get("name")+"\n"+"Time: "+line1.get("time")+"s";
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }


}
